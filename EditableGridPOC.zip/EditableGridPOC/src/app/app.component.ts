import { Component,OnInit  } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
// import {CustomNumberValidator} from './CustomValidator/CustomNumberValidator'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  title = 'EditableGridPOC';
  userForm: FormGroup;
  constructor(private fb: FormBuilder) {}
  ngOnInit() {
    this.userForm = this.fb.group({
           users: this.fb.array([]) 
  });
  }
  initiatForm(): FormGroup {
  return this.fb.group({
      name: ['', Validators.required],  
      email: ['', Validators.required],
      mobNumber: ['']
  });
  }
  addUser() {
    const control = <FormArray>this.userForm.get('users');
    control.push(this.initiatForm());  //---> adding new row
  }
  remove(index: number) {
    const control = <FormArray>this.userForm.get('users');
    control.removeAt(index);  //----> removing selected row
  }
  save() {
    const control = <FormArray>this.userForm.get('users');
    if(!control.valid)
    {
      control.controls.forEach((elsement)=>{
        elsement.markAsTouched();
      });
      
    }
  }


}
